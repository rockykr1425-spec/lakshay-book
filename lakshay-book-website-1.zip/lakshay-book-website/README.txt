LAKSHAY BOOK WEBSITE — SETUP NOTES

Included:
- index.html
- styles.css

Google Tag Manager:
- GTM-W7ZVHKV4 is already included in the <head> and <body> (noscript) locations.
- WhatsApp button clicks push a custom GTM event named: whatsapp_click
- The GTM container still needs a trigger/tag configuration and must be published.

IMPORTANT — BEFORE DEPLOYING:
1. Replace 91XXXXXXXXXX in index.html with the WhatsApp number, including country code, digits only.
   Example format: 919876543210 (do not include +, spaces, or hyphens).
2. Confirm the business wording, contact details, privacy policy, and any required legal disclosures.
3. Do not add betting, wagering, deposit, or payment functionality unless you have confirmed that the service is lawful and properly licensed in every target location.

DEPLOY:
- Give this folder to your developer, or import the project into a Vercel account.
- For a simple static site, upload index.html and styles.css to a Git repository and import it in Vercel.
- After deployment, test with Google Tag Assistant.

WhatsApp conversion configuration:
In Google Tag Manager create a Custom Event trigger:
  Event name: whatsapp_click
Then attach a Google Ads Conversion Tracking tag to that trigger.
Also configure a Conversion Linker on All Pages and verify the Google Ads conversion ID/label in your Google Ads account.
